﻿namespace VKR_Common.Models;

public enum TransactionType
{
    Create,
    Update,
    Delete
}