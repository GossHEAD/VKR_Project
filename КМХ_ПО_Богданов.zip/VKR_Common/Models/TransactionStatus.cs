﻿namespace VKR_Common.Models;

public enum TransactionStatus
{
    Pending,
    Completed,
    Failed
}