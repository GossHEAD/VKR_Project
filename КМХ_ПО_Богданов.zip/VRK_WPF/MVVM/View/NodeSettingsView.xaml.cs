﻿using System.Windows;

namespace VRK_WPF.MVVM.View;

public partial class NodeSettingsView : Window
{
    public NodeSettingsView()
    {
        InitializeComponent();
    }
}