﻿namespace VRK_WPF.MVVM.ViewModel;

public class NodeViewModel
{
    public string Id { get; set; }
    public string Address { get; set; }
    public string Status { get; set; }
}
