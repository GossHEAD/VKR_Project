﻿namespace VKR_Core.Services;

public class HealthMonitoringService
{
    
}