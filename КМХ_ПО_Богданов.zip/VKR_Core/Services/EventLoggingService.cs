﻿namespace VKR_Core.Services;

public class EventLoggingService
{
    
}