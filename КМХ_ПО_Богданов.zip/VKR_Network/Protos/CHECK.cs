﻿namespace VKR_Network.Protos;

public class CHECK
{
    
}